OpenSI lokal connector

Node.js 24+ kerak.
Windows: Start-Windows.cmd faylini oching va papka tanlang.
macOS/Linux: node opensi-connector.mjs --server https://YOUR-OPENSI --code PAIR_CODE --workspace /your/folder

Har loyiha tanlangan papka ichida prj_... nomli alohida katalogda saqlanadi.
Kompyuter yoqilgan va connector ochiq bo‘lsin. Ctrl+C bilan to‘xtating.
Terminal Guided rejimda tasdiq bilan, Avtomatik rejimda topshiriq bo‘yicha shu OS hisobining huquqlari bilan ishlaydi. Bot/API jarayonlari connector ochiq turganda ishlaydi; connector yopilishi ularni to‘xtatadi.
Telefon brauzeridan ham shu hisobning online kompyuter connectorini masofadan boshqarish mumkin. Kompyuter o‘chsa Antigravity offline bo‘ladi. Bulut modellari kompyutersiz ham ishlaydi. Fayllar 1 GB gacha.
